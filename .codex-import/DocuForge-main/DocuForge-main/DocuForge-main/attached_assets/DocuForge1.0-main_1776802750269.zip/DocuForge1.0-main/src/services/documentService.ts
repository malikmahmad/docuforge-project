import { ProjectDetails } from "../types";
import { GoogleGenAI } from "@google/genai";

export async function generateDocumentation(details: ProjectDetails): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  
  if (!apiKey) {
    console.warn("GEMINI_API_KEY not found, falling back to template-based generation.");
    return generateTemplateDocumentation(details);
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const structureMode = details.structureMode || "assistive";
    const customHeadings = details.customHeadings?.trim();

    let modeInstruction = "";
    if (customHeadings) {
      modeInstruction = `
IMPORTANT MODE LOGIC (CUSTOM HEADINGS DETECTED):
The user has provided custom headings:
"${customHeadings}"

- Generate documentation ONLY for the provided headings.
- Do NOT add extra sections.
- Do NOT insert default template sections.
- Do NOT expand structure beyond what user defines.
- Respect exact heading names.
- Maintain proper numbering hierarchy (1, 1.1, 1.1.1).
- If user gives N headings, generate exactly N sections.
- No additional appendix, no roadmap, no risk section unless explicitly requested in the headings.
- VALIDATION: Recheck that number of generated headings = number of user headings.

Structure Mode: ${structureMode}
${structureMode === "strict" ? "→ STRICT: No extra content or suggestions allowed." : "→ ASSISTIVE: Suggest optional missing sections at the end separately (but do not auto-insert into the main document)."}
`;
    } else {
      modeInstruction = `
MODE: AUTOMATIC STRUCTURE
Automatically generate a full enterprise-grade documentation structure (minimum 15 sections).
Use the default structure provided below as a baseline but expand as needed for a professional output.
`;
    }

    const prompt = `You are a Senior Software Architect, Technical Writer, and System Designer. Your task is to generate a COMPLETE, PROFESSIONAL, and INDUSTRY-STANDARD Software Technical Specification (SRS / PRD Hybrid) for the project described below.
    
    CRITICAL RULES:
    - Do NOT leave any section empty.
    - Do NOT generate generic or vague content.
    - Every section must contain REAL, PRACTICAL, and IMPLEMENTABLE details.
    - Use structured formatting (headings, tables, bullet points).
    - Ensure the document looks like it is written for CTOs, investors, and senior engineers.
    - Zero Placeholders: Never use phrases like "TBD" or "To be determined".
    
    MANDATORY DOCUMENT STRUCTURE:
    0. Table of Contents
    1. Executive Summary: Strategic overview of the system's purpose and value.
    2. Project Overview: System scope, stakeholders, and operational constraints.
    3. System Architecture Diagram: A clean text-based (ASCII) diagram of the system.
    4. Problem Statement: Detailed analysis of the pain points being addressed.
    5. Proposed Solution: High-level technical approach and innovation.
    6. System Requirements:
       - 6.1 Functional Requirements: TABLE with [ID, Description, Priority (High/Medium/Low)].
       - 6.2 Non-Functional Requirements:
         • Security: Encryption (AES-256/TLS), Auth (OAuth2/OIDC), RBAC details.
         • Performance: Response time targets, concurrent load handling.
         • SLA: Specific uptime targets (e.g., 99.99%) and error rate thresholds.
         • Rate Limiting & API Throttling: Specific strategy (Token Bucket/Leaky Bucket).
    7. Technology Stack: Specific justification for each layer (Frontend, Backend, DB, AI, etc.).
    8. System Architecture: Layered explanation (Presentation, Application, Data layers).
    9. Data Flow: Step-by-step numbered flow of a core transaction.
    10. Database Design: Tables with fields, types, and descriptions. Include core entities.
    11. API Design (FULL CRUD REQUIRED):
        - Include GET, POST, PUT, DELETE endpoints with clear descriptions and request/response shapes.
    12. Implementation Methodology:
        - Agile Scrum (Sprint cycles, ceremonies).
        - CI/CD Pipeline (Build, Test, Deploy stages).
        - GitFlow (Branching strategy: main, develop, feature, hotfix).
    13. Testing Strategy:
        - Unit Testing, Integration Testing, E2E Testing.
        - If AI system: LLM validation and hallucination check strategies.
    14. Deployment Architecture: Infrastructure setup (Cloud provider, Containerization, Orchestration).
    15. Risk Assessment: Minimum 4 technical/business risks with detailed mitigation strategies.
    16. Performance & Scalability: Caching (Redis), Indexing, and Horizontal Scaling strategies.
    17. Monitoring & Logging: Implementation of Prometheus, Grafana, ELK stack, or similar.
    18. Backup & Recovery Strategy: RPO/RTO targets, automated backup schedules, and disaster recovery plan.
    19. Future Roadmap: Concrete phases for product evolution.
    20. Conclusion: Final architectural sign-off.
    
    ${modeInstruction}
    
    USER INPUT:
    - Project Title: ${details.title}
    - Project Type: ${details.scale === "enterprise" ? "SaaS / AI System" : "Web App"}
    - Purpose: ${details.description}
    - Target Users: ${details.scale} scale users and stakeholders.
    - Core Features: ${details.advancedPrompt || "Standard enterprise features"}
    - Technical Details: ${details.apiDetails || "None provided"}
    
    OUTPUT REQUIREMENTS:
    - Use clean Markdown with hierarchical numbering (1, 1.1, 1.1.1).
    - Ensure all tables are properly formatted.
    - Professional tone throughout.
    - Production-ready content.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text || generateTemplateDocumentation(details);
  } catch (error) {
    console.error("Gemini API error:", error);
    return generateTemplateDocumentation(details);
  }
}

function generateTemplateDocumentation(details: ProjectDetails): string {
  const { title, scale } = details;
  const date = new Date().toLocaleDateString();
  const docId = "DF-" + Math.random().toString(36).substring(2, 9).toUpperCase();

  let content = "# Cover Page\n";
  content += "**Project Name:** " + title + "  \n";
  content += "**Version:** 1.0.0  \n";
  content += "**Prepared By:** DocuForge Senior Architect Engine  \n";
  content += "**Date:** " + date + "  \n";
  content += "**Document ID:** " + docId + "  \n\n";
  content += "---\n\n";
  content += "# Table of Contents\n";
  content += "1. Executive Summary  \n";
  content += "2. Project Overview  \n";
  content += "3. System Architecture Diagram  \n";
  content += "4. Problem Statement  \n";
  content += "5. Proposed Solution  \n";
  content += "6. System Requirements  \n";
  content += "7. Technology Stack  \n";
  content += "8. System Architecture  \n";
  content += "9. Data Flow  \n";
  content += "10. Database Design  \n";
  content += "11. API Design  \n";
  content += "12. Implementation Methodology  \n";
  content += "13. Testing Strategy  \n";
  content += "14. Deployment Architecture  \n";
  content += "15. Risk Assessment  \n";
  content += "16. Performance & Scalability  \n";
  content += "17. Monitoring & Logging  \n";
  content += "18. Backup & Recovery Strategy  \n";
  content += "19. Future Roadmap  \n";
  content += "20. Conclusion  \n\n";
  content += "---\n\n";
  content += "## 1. Executive Summary\n";
  content += "The **" + title + "** project is a high-performance solution designed to address critical documentation gaps through AI-driven automation. This specification serves as the technical blueprint for stakeholders and engineering teams.\n\n";
  
  content += "## 2. Project Overview\n";
  content += "This system provides a robust platform for generating and managing technical specifications at " + scale + " scale. It focuses on reliability, security, and professional output quality.\n\n";

  content += "## 3. System Architecture Diagram\n";
  content += "```text\n";
  content += "[ User Interface ] <---> [ API Gateway ] <---> [ Application Logic ]\n";
  content += "                                                |\n";
  content += "                                      [ Database / Storage ]\n";
  content += "```\n\n";
  
  content += "## 4. Problem Statement\n";
  content += "Current documentation processes are fragmented, inconsistent, and manually intensive, leading to significant technical debt and communication overhead in engineering teams.\n\n";
  
  content += "## 5. Proposed Solution\n";
  content += "DocuForge leverages advanced LLM reasoning to transform project metadata into structured, production-ready technical specifications, ensuring 100% consistency across all artifacts.\n\n";
  
  content += "## 6. System Requirements\n";
  content += "### 6.1 Functional Requirements\n";
  content += "| ID | Description | Priority |\n";
  content += "|---|---|---|\n";
  content += "| FR-01 | AI-driven content generation | High |\n";
  content += "| FR-02 | Multi-format export (PDF/Word/MD) | High |\n";
  content += "| FR-03 | Custom template management | Medium |\n\n";
  
  content += "### 6.2 Non-Functional Requirements\n";
  content += "- **Security:** TLS 1.3 encryption and JWT-based RBAC.\n";
  content += "- **Performance:** P95 response time < 500ms for API requests.\n";
  content += "- **SLA:** 99.99% availability target.\n";
  content += "- **Rate Limiting:** 100 requests per minute per user.\n\n";
  
  content += "## 7. Technology Stack\n";
  content += "| Layer | Technology | Justification |\n";
  content += "|---|---|---|\n";
  content += "| Frontend | React | Industry standard for complex SPAs. |\n";
  content += "| Backend | Node.js | High concurrency for generation tasks. |\n";
  content += "| AI | Gemini | State-of-the-art technical reasoning. |\n\n";
  
  content += "## 8. System Architecture\n";
  content += "A decoupled 3-tier architecture ensuring independent scalability of the presentation, logic, and data layers.\n\n";
  
  content += "## 9. Data Flow\n";
  content += "1. User submits project details via the UI.\n2. API validates request and authenticates user.\n3. Logic layer triggers AI generation engine.\n4. Result is persisted and returned to the client.\n\n";
  
  content += "## 10. Database Design\n";
  content += "| Table | Field | Type | Description |\n";
  content += "|---|---|---|---|\n";
  content += "| Users | id | UUID | Unique identifier |\n";
  content += "| Docs | content | Text | Generated markdown |\n\n";
  
  content += "## 11. API Design\n";
  content += "| Method | Endpoint | Description |\n";
  content += "|---|---|---|\n";
  content += "| GET | /api/docs | List all documents |\n";
  content += "| POST | /api/generate | Create new spec |\n";
  content += "| PUT | /api/docs/:id | Update document |\n";
  content += "| DELETE | /api/docs/:id | Remove document |\n\n";
  
  content += "## 12. Implementation Methodology\n";
  content += "Utilizing Agile Scrum with GitFlow branching and automated CI/CD pipelines for continuous delivery.\n\n";
  
  content += "## 13. Testing Strategy\n";
  content += "Comprehensive test suite including Unit, Integration, and E2E tests with automated LLM output validation.\n\n";
  
  content += "## 14. Deployment Architecture\n";
  content += "Containerized deployment using Docker and Kubernetes for automated orchestration and scaling.\n\n";
  
  content += "## 15. Risk Assessment\n";
  content += "1. AI Hallucination: Mitigated via strict prompt engineering.\n2. Data Privacy: Mitigated via E2E encryption.\n3. Scaling: Mitigated via horizontal pod autoscaling.\n4. API Latency: Mitigated via Redis caching.\n\n";
  
  content += "## 16. Performance & Scalability\n";
  content += "Horizontal scaling of workers and database read-replicas to handle increased load.\n\n";
  
  content += "## 17. Monitoring & Logging\n";
  content += "Full-stack observability using Prometheus for metrics and ELK stack for log aggregation.\n\n";
  
  content += "## 18. Backup & Recovery Strategy\n";
  content += "Daily automated snapshots with a 15-minute RPO and 4-hour RTO target.\n\n";
  
  content += "## 19. Future Roadmap\n";
  content += "Phase 1: Multi-user collaboration. Phase 2: GitHub integration. Phase 3: Custom AI fine-tuning.\n\n";
  
  content += "## 20. Conclusion\n";
  content += "This technical specification provides the definitive guide for the implementation and operation of the " + title + " system.\n\n";

  return content;
}

