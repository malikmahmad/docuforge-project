# DocuForge AI 🛠️

DocuForge AI is a powerful SaaS platform built to take the headache out of technical documentation. Whether you're a startup founder, a product manager, or a senior architect, DocuForge helps you turn project ideas into professional, industry-standard specifications in seconds.

By leveraging advanced reasoning, it generates structured blueprints that are ready for review, stakeholders, or investors.

## ✨ Key Features

- **Comprehensive Blueprints:** Automatically generates 20-section SRS/PRD hybrid documents covering everything from architecture to risk assessment.
- **Customizable Structure:** Need something specific? Use the custom heading override to build exactly what you need.
- **Pro-Grade Exports:** Export your work in high-fidelity PDF, Microsoft Word (.docx), or Markdown (.md) formats.
- **Personal Workspace:** Save, manage, and iterate on your documents within a local workspace.
- **Modern Interface:** A sleek, responsive UI with full dark mode support and smooth animations.

## 🛠️ Tech Stack

- **Frontend:** React 18, Vite, Tailwind CSS, Framer Motion
- **Backend:** Node.js, Express, Better-SQLite3
- **AI Engine:** Google Gemini AI
- **Exporting:** jsPDF, docx, file-saver

## 🚀 Getting Started Locally

Follow these steps to get DocuForge AI running on your machine:

1. **Clone the repository**
2. **Install dependencies:**
   ```bash
   npm install
   ```
3. **Set up your environment:**
   Create a `.env` file in the root directory and add your Gemini API key:
   ```env
   GEMINI_API_KEY=your_google_gemini_api_key
   APP_URL=http://localhost:3000
   ```
4. **Fire it up:**
   ```bash
   npm run dev
   ```
   Head over to `http://localhost:3000` to start forging!

## 🌐 Deployment

### Deploying to GitHub
1. Create a new repository on your GitHub account.
2. Push your local code:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: DocuForge AI Engine"
   git branch -M main
   git remote add origin https://github.com/yourusername/docuforge-ai.git
   git push -u origin main
   ```

### Deploying to Railway
1. Log in to [Railway](https://railway.app/).
2. Create a **New Project** and select **Deploy from GitHub repo**.
3. Choose your DocuForge repository.
4. **Configure Variables:**
   In the **Variables** tab, add:
   - `GEMINI_API_KEY`: Your Google Gemini API key.
   - `APP_URL`: Your live Railway URL (e.g., `https://docuforge.up.railway.app`).
   - `NODE_ENV`: `production`
5. **Build Info:**
   The project includes a `nixpacks.toml` to handle the build tools needed for the SQLite engine. Railway will handle this automatically.
6. **Persistence:**
   For production, consider mounting a volume for `database.sqlite` or switching to a managed database if you expect high traffic.

## 📂 Project Structure

- `/src`: The React frontend.
- `/server.ts`: Our Express backend and API logic.
- `/database.sqlite`: The local database (created automatically).
- `nixpacks.toml`: Build configuration for cloud deployment.
