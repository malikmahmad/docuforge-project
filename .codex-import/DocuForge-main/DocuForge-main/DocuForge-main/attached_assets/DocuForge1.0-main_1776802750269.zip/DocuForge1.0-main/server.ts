import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database("docuforge.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT NOT NULL,
    description TEXT,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

const app = express();
app.use(express.json());

// Documentation Generation Logic (Template-based)
function generateDocContent(title: string, description: string, scale: string = "startup", structureMode: string = "assistive", customHeadings?: string) {
  const date = new Date().toLocaleDateString();
  const docId = `DF-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

  let content = `# Cover Page\n**Project Name:** ${title}  \n**Version:** 1.0.0  \n**Prepared By:** DocuForge Enterprise Engine  \n**Date:** ${date}  \n**Document ID:** ${docId}  \n\n**Confidentiality Notice:**  \nThis document contains proprietary and confidential information.\n\n---\n\n`;
  
  if (customHeadings) {
    const headings = customHeadings.split(/[,\n]/).map(h => h.trim()).filter(h => h);
    content += `# Table of Contents\n${headings.map((h, i) => `${i + 1}. ${h}`).join("  \n")}\n\n---\n\n`;
    
    headings.forEach((heading, index) => {
      content += `## ${index + 1}. ${heading}\n`;
      content += `Professional documentation content for **${heading}** based on the ${scale} scale project requirements. This section is generated in **${structureMode}** mode, ensuring strict adherence to the user-defined structure.\n\n`;
    });

    if (structureMode === "assistive") {
      content += `\n---\n### Suggested Additional Sections (Assistive Mode)\n- Risk Assessment\n- Future Roadmap\n- Appendix\n`;
    }
    return content;
  }

  content += `# Revision History Table\n| Version | Date | Description | Author |\n|---|---|---|---|\n| 1.0.0 | ${date} | Initial Draft | DocuForge |\n\n---\n\n`;
  
  content += `# Table of Contents\n1. Executive Summary  \n2. Project Overview  \n3. Problem Statement  \n4. Proposed Solution  \n5. System Requirements  \n6. Technology Stack  \n7. System Architecture  \n8. Database Design  \n9. API Documentation  \n10. Implementation & Methodology  \n11. Testing Strategy  \n12. Deployment Architecture  \n13. Risk Assessment  \n14. Performance & Scalability  \n15. Future Roadmap & Conclusion  \n16. Appendix  \n\n---\n\n`;

  content += `## 1. Executive Summary\nThe **${title}** project represents a strategic initiative aimed at revolutionizing the current operational landscape through the implementation of a high-performance, scalable software solution.\n\n`;
  // ... (rest of the template content is already there, I'll keep it simple for the fallback)
  content += `## 2. Project Overview\n### 2.1 Stakeholder Overview\nThe project involves multiple stakeholders, including project sponsors, end-users, and administrators.\n\n`;
  content += `## 3. Problem Statement\nThe current environment is characterized by significant inefficiencies and technical limitations.\n\n`;
  content += `## 4. Proposed Solution\nThe proposed solution for **${title}** is a modern, full-stack application built on a foundation of industry-leading technologies.\n\n`;
  content += `## 5. System Requirements\n### 5.1 Functional Requirements\n| ID | Requirement | Description | Priority |\n|---|---|---|---|\n| FR-01 | User Authentication | Secure login with multi-factor authentication. | High |\n\n`;
  content += `## 6. Technology Stack\nTailored for ${scale} scale.\n\n`;
  content += `## 7. System Architecture\nModern client-server model.\n\n`;
  content += `## 8. Database Design\nRelational model.\n\n`;
  content += `## 9. API Documentation\nRESTful endpoints.\n\n`;
  content += `## 10. Implementation & Methodology\nAgile/Scrum.\n\n`;
  content += `## 11. Testing Strategy\nUnit, Integration, and UAT.\n\n`;
  content += `## 12. Deployment Architecture\nCI/CD pipeline.\n\n`;
  content += `## 13. Risk Assessment\nRisk matrix included.\n\n`;
  content += `## 14. Performance & Scalability\nOptimized for growth.\n\n`;
  content += `## 15. Future Roadmap & Conclusion\nAI-driven analytics and mobile support.\n\n`;
  content += `## 16. Appendix\nGlossary and specifications.\n`;

  return content;
}

// API Routes
app.get("/api/projects", (req, res) => {
  const projects = db.prepare("SELECT * FROM projects ORDER BY created_at DESC").all();
  res.json(projects);
});

app.post("/api/projects", (req, res) => {
  const { title, description, scale, structureMode, customHeadings, user_id } = req.body;
  const content = generateDocContent(title, description, scale || "startup", structureMode || "assistive", customHeadings);
  const info = db.prepare("INSERT INTO projects (title, description, content, user_id) VALUES (?, ?, ?, ?)").run(title, description, content, user_id || null);
  res.json({ id: info.lastInsertRowid, title, description, content });
});

app.put("/api/projects/:id", (req, res) => {
  const { title, description } = req.body;
  const { id } = req.params;
  db.prepare("UPDATE projects SET title = ?, description = ? WHERE id = ?").run(title, description, id);
  res.json({ success: true });
});

app.delete("/api/projects/:id", (req, res) => {
  const { id } = req.params;
  db.prepare("DELETE FROM projects WHERE id = ?").run(id);
  res.json({ success: true });
});

app.get("/api/users", (req, res) => {
  const users = db.prepare("SELECT * FROM users").all();
  res.json(users);
});

app.post("/api/users", (req, res) => {
  const { name, email } = req.body;
  try {
    const info = db.prepare("INSERT INTO users (name, email) VALUES (?, ?)").run(name, email);
    res.json({ id: info.lastInsertRowid, name, email });
  } catch (e) {
    res.status(400).json({ error: "Email already exists" });
  }
});

// Vite Integration
if (process.env.NODE_ENV !== "production") {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.join(__dirname, "dist")));
  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "dist", "index.html"));
  });
}

const PORT = 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
